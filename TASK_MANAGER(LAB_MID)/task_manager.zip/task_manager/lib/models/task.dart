class Subtask {
  String id;
  String title;
  bool isCompleted;

  Subtask({
    required this.id,
    required this.title,
    this.isCompleted = false,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'isCompleted': isCompleted,
  };

  factory Subtask.fromJson(Map<String, dynamic> json) => Subtask(
    id: json['id'],
    title: json['title'],
    isCompleted: json['isCompleted'] ?? false,
  );
}

class Task {
  String id;
  String title;
  String description;
  DateTime dueDate;
  int? dueHour;
  int? dueMinute;
  bool isCompleted;
  bool isRepeated;
  List<String> repeatDays;
  List<Subtask> subtasks;
  int? notificationId;
  String notificationSound;
  DateTime createdAt;
  List<String> completedDates;
  String priority;
  String category;

  Task({
    required this.id,
    required this.title,
    this.description = '',
    required this.dueDate,
    this.dueHour,
    this.dueMinute,
    this.isCompleted = false,
    this.isRepeated = false,
    List<String>? repeatDays,
    List<Subtask>? subtasks,
    this.notificationId,
    this.notificationSound = 'default',
    required this.createdAt,
    List<String>? completedDates,
    this.priority = 'medium',
    this.category = 'Personal',
  })  : repeatDays = repeatDays ?? [],
        subtasks = subtasks ?? [],
        completedDates = completedDates ?? [];

  bool get isOverdue {
    if (isCompleted) return false;
    final now = DateTime.now();
    // ✅ toLocal() — UTC datetime ke saath year/month/day galat tha
    final local = dueDate.toLocal();
    if (dueHour != null) {
      final due = DateTime(
          local.year, local.month, local.day, dueHour!, dueMinute ?? 0);
      return due.isBefore(now);
    }
    // ✅ Future tasks kabhi overdue nahi — local midnight compare
    final dueMidnight = DateTime(local.year, local.month, local.day);
    final todayMidnight = DateTime(now.year, now.month, now.day);
    return dueMidnight.isBefore(todayMidnight);
  }

  double get progress {
    if (subtasks.isEmpty) return isCompleted ? 1.0 : 0.0;
    int done = subtasks.where((s) => s.isCompleted).length;
    return done / subtasks.length;
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'description': description,
    'dueDate': dueDate.toLocal().toIso8601String(), // ✅ hamesha local save
    'dueHour': dueHour,
    'dueMinute': dueMinute,
    'isCompleted': isCompleted,
    'isRepeated': isRepeated,
    'repeatDays': repeatDays,
    'subtasks': subtasks.map((s) => s.toJson()).toList(),
    'notificationId': notificationId,
    'notificationSound': notificationSound,
    'createdAt': createdAt.toLocal().toIso8601String(), // ✅ hamesha local save
    'completedDates': completedDates,
    'priority': priority,
    'category': category,
  };

  factory Task.fromJson(Map<String, dynamic> json) => Task(
    id: json['id'],
    title: json['title'],
    description: json['description'] ?? '',
    dueDate: DateTime.parse(json['dueDate']).toLocal(), // ✅ UTC→local normalize
    dueHour: json['dueHour'],
    dueMinute: json['dueMinute'],
    isCompleted: json['isCompleted'] ?? false,
    isRepeated: json['isRepeated'] ?? false,
    repeatDays: List<String>.from(json['repeatDays'] ?? []),
    subtasks: (json['subtasks'] as List? ?? [])
        .map((s) => Subtask.fromJson(s))
        .toList(),
    notificationId: json['notificationId'],
    notificationSound: json['notificationSound'] ?? 'default',
    createdAt: DateTime.parse(json['createdAt']).toLocal(), // ✅ UTC→local normalize
    completedDates:
    List<String>.from(json['completedDates'] ?? []),
    priority: json['priority'] ?? 'medium',
    category: json['category'] ?? 'Personal',
  );
}
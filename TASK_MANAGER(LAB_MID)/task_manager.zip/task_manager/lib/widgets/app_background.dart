import 'package:flutter/material.dart';

class AppBackground extends StatelessWidget {
  final Widget child;
  final double lightOpacity;
  final double darkOpacity;

  const AppBackground({
    super.key,
    required this.child,
    this.lightOpacity = 0.15,
    this.darkOpacity = 0.25,
  });

  @override
  Widget build(BuildContext context) {
    // ✅ Theme check karo
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Stack(
      children: [
        // ✅ Light/Dark image automatically switch
        Positioned.fill(
          child: Image.asset(
            isDark
                ? 'assets/images/bg_dark.png' // dark mode
                : 'assets/images/bg.png',      // light mode
            fit: BoxFit.cover,
          ),
        ),
        // ✅ Overlay opacity bhi theme ke mutabiq
        Positioned.fill(
          child: Container(
            color: Colors.black.withOpacity(
              isDark ? darkOpacity : lightOpacity,
            ),
          ),
        ),
        child,
      ],
    );
  }
}
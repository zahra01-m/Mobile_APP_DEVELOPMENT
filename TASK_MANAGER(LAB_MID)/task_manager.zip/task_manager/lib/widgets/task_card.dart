import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../models/task.dart';
import '../providers/task_provider.dart';
import '../screens/add_task_screen.dart';
import '../screens/task_detail_screen.dart';

class TaskCard extends StatelessWidget {
  final Task task;
  const TaskCard({super.key, required this.task});

  String get _todayStr => DateFormat('yyyy-MM-dd').format(DateTime.now());

  bool get _isCompletedToday {
    if (task.isRepeated) return task.completedDates.contains(_todayStr);
    return task.isCompleted;
  }

  Color get _priorityColor {
    switch (task.priority) {
      case 'high': return Colors.red;
      case 'low': return Colors.green;
      default: return Colors.orange;
    }
  }

  Color get _categoryColor {
    switch (task.category) {
      case 'Work': return Colors.blue;
      case 'Study': return Colors.purple;
      case 'Health': return Colors.green;
      case 'Personal': return Colors.pink;
      default: return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.read<TaskProvider>();
    final theme = Theme.of(context);

    return Dismissible(
      key: Key(task.id),
      direction: DismissDirection.endToStart,
      background: Container(
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 20),
        margin: const EdgeInsets.only(bottom: 12),
        decoration: BoxDecoration(
          color: Colors.red.shade400,
          borderRadius: BorderRadius.circular(12),
        ),
        child: const Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.delete_outline, color: Colors.white, size: 28),
            SizedBox(height: 4),
            Text('Delete', style: TextStyle(color: Colors.white, fontSize: 12)),
          ],
        ),
      ),
      confirmDismiss: (_) async {
        return await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('Delete Task'),
            content: Text('Delete "${task.title}"?'),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(ctx, false),
                  child: const Text('Cancel')),
              TextButton(
                onPressed: () => Navigator.pop(ctx, true),
                style: TextButton.styleFrom(foregroundColor: Colors.red),
                child: const Text('Delete'),
              ),
            ],
          ),
        );
      },
      onDismissed: (_) => provider.deleteTask(task.id),
      child: AnimatedOpacity(
        // ✅ Strikethrough hataya — opacity use karo, zyada clean lagta hai
        opacity: _isCompletedToday ? 0.5 : 1.0,
        duration: const Duration(milliseconds: 300),
        child: Card(
          margin: const EdgeInsets.only(bottom: 12),
          elevation: _isCompletedToday ? 0 : 2, // ✅ complete hone pe flat
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12)),
          child: InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => TaskDetailScreen(task: task))),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                border: Border(
                  left: BorderSide(
                    // ✅ Complete hone pe green border
                    color: _isCompletedToday ? Colors.green : _priorityColor,
                    width: 5,
                  ),
                ),
              ),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // ── Title row ──────────────────
                      Row(children: [
                        Checkbox(
                          value: _isCompletedToday,
                          activeColor: Colors.green,
                          onChanged: (_) async {
                            await provider.toggleComplete(task.id);
                          },
                        ),
                        Expanded(
                          child: Text(
                            task.title,
                            style: theme.textTheme.titleMedium?.copyWith(
                              // ✅ Complete hone pe sirf color grey — no strikethrough
                              color: _isCompletedToday
                                  ? Colors.grey
                                  : null,
                              fontWeight: _isCompletedToday
                                  ? FontWeight.normal
                                  : FontWeight.w600,
                            ),
                          ),
                        ),
                        // ✅ Complete hone pe priority badge hide
                        if (!_isCompletedToday)
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(
                              color: _priorityColor.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(
                                  color: _priorityColor.withOpacity(0.4)),
                            ),
                            child: Text(
                              task.priority.toUpperCase(),
                              style: TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                  color: _priorityColor),
                            ),
                          ),
                        if (_isCompletedToday)
                        // ✅ Complete badge
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(
                              color: Colors.green.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(
                                  color: Colors.green.withOpacity(0.4)),
                            ),
                            child: const Text(
                              'DONE ✓',
                              style: TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.green),
                            ),
                          ),
                        const SizedBox(width: 4),
                        if (task.isRepeated)
                          Icon(Icons.repeat,
                              size: 16,
                              color: theme.colorScheme.primary),
                        IconButton(
                          icon: const Icon(Icons.edit_outlined, size: 18),
                          onPressed: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) => AddTaskScreen(task: task))),
                        ),
                      ]),

                      // ── Category chip ───────────────
                      Padding(
                        padding:
                        const EdgeInsets.only(left: 52, bottom: 6),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                            color: _categoryColor.withOpacity(0.12),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(task.category,
                              style: TextStyle(
                                  fontSize: 11, color: _categoryColor)),
                        ),
                      ),

                      // ── Description ─────────────────
                      if (task.description.isNotEmpty)
                        Padding(
                          padding:
                          const EdgeInsets.only(left: 52, bottom: 4),
                          child: Text(task.description,
                              style: theme.textTheme.bodySmall,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis),
                        ),

                      // ── Date + time ─────────────────
                      Padding(
                        padding: const EdgeInsets.only(left: 52),
                        child: Row(children: [
                          if (task.isOverdue && !_isCompletedToday) ...[
                            const Icon(Icons.warning_amber_rounded,
                                size: 12, color: Colors.red),
                            const SizedBox(width: 4),
                            const Text('Overdue',
                                style: TextStyle(
                                    fontSize: 11,
                                    color: Colors.red,
                                    fontWeight: FontWeight.bold)),
                            const SizedBox(width: 8),
                          ],
                          Icon(Icons.calendar_today,
                              size: 12, color: Colors.grey[600]),
                          const SizedBox(width: 4),
                          Text(
                            DateFormat('MMM dd, yyyy').format(task.dueDate),
                            style: TextStyle(
                                fontSize: 12, color: Colors.grey[600]),
                          ),
                          if (task.dueHour != null) ...[
                            const SizedBox(width: 8),
                            Icon(Icons.access_time,
                                size: 12, color: Colors.grey[600]),
                            const SizedBox(width: 4),
                            Text(
                              '${task.dueHour!.toString().padLeft(2, '0')}:'
                                  '${task.dueMinute!.toString().padLeft(2, '0')}',
                              style: TextStyle(
                                  fontSize: 12, color: Colors.grey[600]),
                            ),
                          ],
                        ]),
                      ),

                      // ── Subtask progress ────────────
                      if (task.subtasks.isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.only(
                              left: 52, top: 8, right: 8),
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                    mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text('Progress',
                                          style: TextStyle(
                                              fontSize: 11,
                                              color: Colors.grey[600])),
                                      Text(
                                          '${(task.progress * 100).toInt()}%',
                                          style: TextStyle(
                                              fontSize: 11,
                                              color: theme.colorScheme.primary,
                                              fontWeight: FontWeight.bold)),
                                    ]),
                                const SizedBox(height: 4),
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(4),
                                  child: LinearProgressIndicator(
                                    value: task.progress,
                                    minHeight: 6,
                                    backgroundColor: Colors.grey[200],
                                    valueColor: AlwaysStoppedAnimation<Color>(
                                        _isCompletedToday
                                            ? Colors.green
                                            : _priorityColor),
                                  ),
                                ),
                              ]),
                        ),
                    ]),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
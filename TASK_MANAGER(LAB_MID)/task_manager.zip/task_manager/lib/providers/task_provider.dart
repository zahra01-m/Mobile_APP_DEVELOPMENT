import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/task.dart';
import '../services/storage_service.dart';

class TaskProvider extends ChangeNotifier {
  List<Task> _tasks = [];
  List<Task> get tasks => _tasks;

  String _todayStr() => DateFormat('yyyy-MM-dd').format(DateTime.now());
  String _dayName() => DateFormat('EEE').format(DateTime.now());
  String _dateStr(DateTime dt) => DateFormat('yyyy-MM-dd').format(dt);

  bool _isCompletedToday(Task t) {
    if (t.isRepeated) return t.completedDates.contains(_todayStr());
    return t.isCompleted;
  }

  // ✅ Sirf aaj ke tasks
  List<Task> get todayTasks {
    final today = _todayStr();
    final day = _dayName();
    return _tasks.where((t) {
      if (_isCompletedToday(t)) return false;
      if (t.isRepeated) {
        return t.repeatDays.contains('daily') || t.repeatDays.contains(day);
      }
      return _dateStr(t.dueDate) == today;
    }).toList();
  }

  // ✅ Future tasks — aaj ke baad ke
  List<Task> get futureTasks {
    final today = _todayStr();
    return _tasks.where((t) {
      if (_isCompletedToday(t)) return false;
      if (t.isRepeated) return false;
      if (t.isCompleted) return false;
      return _dateStr(t.dueDate).compareTo(today) > 0;
    }).toList()
      ..sort((a, b) => a.dueDate.compareTo(b.dueDate)); // ✅ date se sort
  }

  List<Task> get completedTasks =>
      _tasks.where((t) => _isCompletedToday(t)).toList();

  List<Task> get repeatedTasks =>
      _tasks.where((t) => t.isRepeated).toList();

  List<Task> get overdueTasks => _tasks.where((t) {
    if (_isCompletedToday(t)) return false;
    if (t.isRepeated) return false;
    if (!t.isOverdue) return false;
    return _dateStr(t.dueDate) != _todayStr();
  }).toList();

  List<Task> searchTasks(String query) {
    if (query.isEmpty) return _tasks;
    final q = query.toLowerCase();
    return _tasks
        .where((t) =>
    t.title.toLowerCase().contains(q) ||
        t.description.toLowerCase().contains(q) ||
        t.category.toLowerCase().contains(q))
        .toList();
  }

  int get totalCount => _tasks.length;
  int get completedCount =>
      _tasks.where((t) => _isCompletedToday(t)).length;
  int get pendingCount =>
      _tasks.where((t) => !_isCompletedToday(t)).length;
  int get highPriorityCount =>
      _tasks.where((t) => t.priority == 'high').length;
  int get overdueCount => overdueTasks.length;
  double get completionRate =>
      totalCount == 0 ? 0.0 : completedCount / totalCount;

  Future<void> loadTasks() async {
    _tasks = await StorageService.loadTasks();
    notifyListeners();
  }

  Task? getTaskById(String id) {
    try {
      return _tasks.firstWhere((t) => t.id == id);
    } catch (_) {
      return null;
    }
  }

  Future<void> addTask(Task task) async {
    _tasks.add(task);
    await StorageService.saveTasks(_tasks);
    notifyListeners();
  }

  Future<void> updateTask(Task updated) async {
    final i = _tasks.indexWhere((t) => t.id == updated.id);
    if (i != -1) {
      _tasks[i] = updated;
      await StorageService.saveTasks(_tasks);
      notifyListeners();
    }
  }

  Future<void> deleteTask(String id) async {
    _tasks.removeWhere((t) => t.id == id);
    await StorageService.saveTasks(_tasks);
    notifyListeners();
  }

  Future<void> toggleComplete(String id) async {
    final i = _tasks.indexWhere((t) => t.id == id);
    if (i == -1) return;
    final t = _tasks[i];
    final today = _todayStr();

    if (t.isRepeated) {
      final dates = List<String>.from(t.completedDates);
      dates.contains(today) ? dates.remove(today) : dates.add(today);
      _tasks[i] = Task(
        id: t.id, title: t.title, description: t.description,
        dueDate: t.dueDate, dueHour: t.dueHour, dueMinute: t.dueMinute,
        isCompleted: t.isCompleted, isRepeated: t.isRepeated,
        repeatDays: t.repeatDays, subtasks: t.subtasks,
        notificationId: t.notificationId,
        notificationSound: t.notificationSound,
        createdAt: t.createdAt, completedDates: dates,
        priority: t.priority, category: t.category,
      );
    } else {
      _tasks[i] = Task(
        id: t.id, title: t.title, description: t.description,
        dueDate: t.dueDate, dueHour: t.dueHour, dueMinute: t.dueMinute,
        isCompleted: !t.isCompleted, isRepeated: t.isRepeated,
        repeatDays: t.repeatDays, subtasks: t.subtasks,
        notificationId: t.notificationId,
        notificationSound: t.notificationSound,
        createdAt: t.createdAt, completedDates: t.completedDates,
        priority: t.priority, category: t.category,
      );
    }
    await StorageService.saveTasks(_tasks);
    notifyListeners();
  }

  Future<void> toggleSubtask(String taskId, String subtaskId) async {
    final ti = _tasks.indexWhere((t) => t.id == taskId);
    if (ti == -1) return;
    final t = _tasks[ti];
    final subs = t.subtasks
        .map((s) => s.id == subtaskId
        ? Subtask(id: s.id, title: s.title, isCompleted: !s.isCompleted)
        : s)
        .toList();
    _tasks[ti] = Task(
      id: t.id, title: t.title, description: t.description,
      dueDate: t.dueDate, dueHour: t.dueHour, dueMinute: t.dueMinute,
      isCompleted: t.isCompleted, isRepeated: t.isRepeated,
      repeatDays: t.repeatDays, subtasks: subs,
      notificationId: t.notificationId,
      notificationSound: t.notificationSound,
      createdAt: t.createdAt, completedDates: t.completedDates,
      priority: t.priority, category: t.category,
    );
    await StorageService.saveTasks(_tasks);
    notifyListeners();
  }
}
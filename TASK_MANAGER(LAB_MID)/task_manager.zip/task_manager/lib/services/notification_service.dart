import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

class NotificationService {
  NotificationService._();

  static final FlutterLocalNotificationsPlugin _plugin =
  FlutterLocalNotificationsPlugin();

  static bool _initialized = false;

  // ✅ Sound name se RawResource map
  static RawResourceAndroidNotificationSound _getSound(String soundName) {
    switch (soundName) {
      case 'bell':
        return const RawResourceAndroidNotificationSound('ringingtone');
      case 'chime':
        return const RawResourceAndroidNotificationSound('tone');
      case 'alarm':
        return const RawResourceAndroidNotificationSound('notification');
      default:
        return const RawResourceAndroidNotificationSound('notification');
    }
  }

  // ─── Initialize ────────────────────────────────────────────────────────────
  static Future<void> initialize() async {
    if (kIsWeb) return;
    if (_initialized) return;

    const AndroidInitializationSettings androidSettings =
    AndroidInitializationSettings('@mipmap/ic_launcher');

    const InitializationSettings settings =
    InitializationSettings(android: androidSettings);

    await _plugin.initialize(
      settings,
      onDidReceiveNotificationResponse: _onNotificationTap,
      onDidReceiveBackgroundNotificationResponse: _onNotificationTap,
    );

    try {
      final AndroidNotificationChannel channel = AndroidNotificationChannel(
        'task_channel',
        'Task Notifications',
        description: 'Reminders for your tasks',
        importance: Importance.max,
        playSound: true,
        enableVibration: true,
        sound: const RawResourceAndroidNotificationSound('notification'),
      );

      final AndroidFlutterLocalNotificationsPlugin? androidPlugin = _plugin
          .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();

      await androidPlugin?.createNotificationChannel(channel);
      await androidPlugin?.requestNotificationsPermission();
    } catch (e) {
      debugPrint('Notification channel setup error: $e');
    }

    _initialized = true;
    await _checkLaunchNotification();
  }

  @pragma('vm:entry-point')
  static void _onNotificationTap(NotificationResponse response) {
    final payload = response.payload;
    if (payload != null && payload.isNotEmpty) {
      navigatorKey.currentState?.pushNamed('/task-detail', arguments: payload);
    } else {
      navigatorKey.currentState
          ?.pushNamedAndRemoveUntil('/', (route) => false);
    }
  }

  static Future<void> _checkLaunchNotification() async {
    final details = await _plugin.getNotificationAppLaunchDetails();
    if (details != null &&
        details.didNotificationLaunchApp &&
        details.notificationResponse != null) {
      final payload = details.notificationResponse!.payload;
      if (payload != null && payload.isNotEmpty) {
        Future.delayed(const Duration(milliseconds: 500), () {
          navigatorKey.currentState
              ?.pushNamed('/task-detail', arguments: payload);
        });
      }
    }
  }

  // ─── Schedule Notification ─────────────────────────────────────────────────
  static Future<void> scheduleNotification({
    required int id,
    required String title,
    required String body,
    required DateTime scheduledDate,
    String? taskId,
    String soundName = 'default', // ✅ sound parameter
  }) async {
    if (kIsWeb) return;

    if (scheduledDate.isBefore(DateTime.now())) {
      debugPrint('Notification skipped — time already passed');
      return;
    }

    final sound = _getSound(soundName); // ✅ sound select karo

    try {
      await _plugin.zonedSchedule(
        id,
        title,
        body,
        tz.TZDateTime.from(scheduledDate, tz.local),
        NotificationDetails(
          android: AndroidNotificationDetails(
            'task_channel',
            'Task Notifications',
            channelDescription: 'Reminders for your tasks',
            importance: Importance.max,
            priority: Priority.high,
            playSound: true,
            enableVibration: true,
            sound: sound, // ✅ selected sound
          ),
        ),
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        uiLocalNotificationDateInterpretation:
        UILocalNotificationDateInterpretation.absoluteTime,
        payload: taskId,
      );
      debugPrint('Notification scheduled: $scheduledDate, sound: $soundName');
    } catch (e) {
      debugPrint('Schedule notification error: $e');
    }
  }

  // ─── Show Instant Notification ─────────────────────────────────────────────
  static Future<void> showInstantNotification({
    required int id,
    required String title,
    required String body,
    String? taskId,
    String soundName = 'default',
  }) async {
    if (kIsWeb) return;

    final sound = _getSound(soundName);

    try {
      await _plugin.show(
        id,
        title,
        body,
        NotificationDetails(
          android: AndroidNotificationDetails(
            'task_channel',
            'Task Notifications',
            importance: Importance.max,
            priority: Priority.high,
            playSound: true,
            enableVibration: true,
            sound: sound,
          ),
        ),
        payload: taskId,
      );
    } catch (e) {
      debugPrint('Show notification error: $e');
    }
  }

  // ─── Cancel Notification ───────────────────────────────────────────────────
  static Future<void> cancelNotification(int id) async {
    if (kIsWeb) return;
    try {
      await _plugin.cancel(id);
    } catch (e) {
      debugPrint('Cancel notification error: $e');
    }
  }

  // ─── Cancel All ────────────────────────────────────────────────────────────
  static Future<void> cancelAll() async {
    if (kIsWeb) return;
    try {
      await _plugin.cancelAll();
    } catch (e) {
      debugPrint('Cancel all notifications error: $e');
    }
  }
}
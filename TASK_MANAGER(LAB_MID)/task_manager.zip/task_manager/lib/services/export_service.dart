import 'dart:io';
import 'package:csv/csv.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:url_launcher/url_launcher.dart';
import '../models/task.dart';

class ExportService {
  final _fmt = DateFormat('MMM dd, yyyy');

  Future<void> exportToCSV(List<Task> tasks) async {
    final rows = [
      ['Title', 'Description', 'Due Date', 'Status',
       'Priority', 'Category', 'Repeated', 'Progress'],
      ...tasks.map((t) => [
            t.title,
            t.description,
            _fmt.format(t.dueDate),
            t.isCompleted ? 'Completed' : 'Pending',
            t.priority,
            t.category,
            t.isRepeated ? 'Yes' : 'No',
            '${(t.progress * 100).toInt()}%',
          ]),
    ];
    final csv = const ListToCsvConverter().convert(rows);
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/tasks_export.csv');
    await file.writeAsString(csv);
    await Share.shareXFiles([XFile(file.path)], text: 'My Tasks Export');
  }

  Future<void> exportToPDF(List<Task> tasks) async {
    final pdf = pw.Document();
    pdf.addPage(pw.MultiPage(
      pageFormat: PdfPageFormat.a4,
      build: (ctx) => [
        pw.Text('Task Manager Export',
            style: pw.TextStyle(
                fontSize: 22, fontWeight: pw.FontWeight.bold)),
        pw.Text('Generated: ${_fmt.format(DateTime.now())}',
            style: const pw.TextStyle(
                fontSize: 11, color: PdfColors.grey600)),
        pw.SizedBox(height: 20),
        ...tasks.map((t) => pw.Container(
              margin: const pw.EdgeInsets.only(bottom: 12),
              padding: const pw.EdgeInsets.all(10),
              decoration: pw.BoxDecoration(
                border: pw.Border.all(color: PdfColors.grey300),
                borderRadius:
                    const pw.BorderRadius.all(pw.Radius.circular(6)),
              ),
              child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    pw.Text(t.title,
                        style: pw.TextStyle(
                            fontWeight: pw.FontWeight.bold,
                            fontSize: 14)),
                    pw.Text(
                        'Due: ${_fmt.format(t.dueDate)} | '
                        '${t.isCompleted ? "Completed" : "Pending"} | '
                        'Priority: ${t.priority} | ${t.category}',
                        style: const pw.TextStyle(
                            fontSize: 11,
                            color: PdfColors.grey700)),
                  ]),
            )),
      ],
    ));
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/tasks_export.pdf');
    await file.writeAsBytes(await pdf.save());
    await Share.shareXFiles([XFile(file.path)], subject: 'Tasks PDF');
  }

  Future<void> exportViaEmail(List<Task> tasks) async {
    final buf = StringBuffer()
      ..writeln('Task Manager Export')
      ..writeln('===================\n');
    for (final t in tasks) {
      buf
        ..writeln('• ${t.title} [${t.priority.toUpperCase()}]')
        ..writeln('  Category: ${t.category}')
        ..writeln('  Due: ${_fmt.format(t.dueDate)}')
        ..writeln('  Status: ${t.isCompleted ? "Completed" : "Pending"}')
        ..writeln();
    }
    final uri = Uri(
      scheme: 'mailto',
      query: 'subject=My Tasks&body=${Uri.encodeComponent(buf.toString())}',
    );
    if (await canLaunchUrl(uri)) await launchUrl(uri);
  }
}
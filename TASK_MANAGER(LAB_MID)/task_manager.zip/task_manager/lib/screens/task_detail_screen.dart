import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../models/task.dart';
import '../providers/task_provider.dart';
import 'add_task_screen.dart';

class TaskDetailScreen extends StatelessWidget {
  final Task task;
  const TaskDetailScreen({super.key, required this.task});

  Color get _priorityColor {
    switch (task.priority) {
      case 'high':
        return Colors.red;
      case 'low':
        return Colors.green;
      default:
        return Colors.orange;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<TaskProvider>(builder: (_, provider, __) {
      final t = provider.tasks.firstWhere(
        (x) => x.id == task.id,
        orElse: () => task,
      );

      return Scaffold(
        appBar: AppBar(
          title: const Text('Task Details'),
          actions: [
            IconButton(
              icon: const Icon(Icons.edit),
              onPressed: () => Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                      builder: (_) => AddTaskScreen(task: t))),
            ),
          ],
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Title card
                Card(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      border: Border(
                          left: BorderSide(
                              color: _priorityColor, width: 5)),
                    ),
                    child: ListTile(
                      leading: Checkbox(
                          value: t.isCompleted,
                          onChanged: (_) =>
                              provider.toggleComplete(t.id)),
                      title: Text(t.title,
                          style: Theme.of(context)
                              .textTheme
                              .titleLarge
                              ?.copyWith(
                                  decoration: t.isCompleted
                                      ? TextDecoration.lineThrough
                                      : null)),
                      subtitle: Row(children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(
                            color:
                                _priorityColor.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            t.priority.toUpperCase(),
                            style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                                color: _priorityColor),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(t.category,
                            style:
                                const TextStyle(fontSize: 13)),
                      ]),
                    ),
                  ),
                ),

                // Overdue warning
                if (t.isOverdue && !t.isCompleted) ...[
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: Colors.red.shade50,
                      borderRadius: BorderRadius.circular(8),
                      border:
                          Border.all(color: Colors.red.shade200),
                    ),
                    child: const Row(children: [
                      Icon(Icons.warning_amber_rounded,
                          color: Colors.red, size: 18),
                      SizedBox(width: 8),
                      Text('This task is overdue!',
                          style: TextStyle(
                              color: Colors.red,
                              fontWeight: FontWeight.w500)),
                    ]),
                  ),
                ],

                const SizedBox(height: 12),

                // Info card
                Card(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                        crossAxisAlignment:
                            CrossAxisAlignment.start,
                        children: [
                          if (t.description.isNotEmpty) ...[
                            _label('Description'),
                            Text(t.description),
                            const Divider(height: 24),
                          ],
                          _row(Icons.calendar_today, 'Due Date',
                              DateFormat('EEE, MMMM dd yyyy')
                                  .format(t.dueDate)),
                          if (t.dueHour != null)
                            _row(
                                Icons.access_time,
                                'Due Time',
                                '${t.dueHour!.toString().padLeft(2, '0')}'
                                    ':${t.dueMinute!.toString().padLeft(2, '0')}'),
                          if (t.isRepeated)
                            _row(
                                Icons.repeat,
                                'Repeats',
                                t.repeatDays.contains('daily')
                                    ? 'Every Day'
                                    : t.repeatDays.join(', ')),
                          _row(Icons.notifications_outlined,
                              'Notification Sound',
                              t.notificationSound),
                          _row(
                              Icons.info_outline,
                              'Created',
                              DateFormat('MMM dd, yyyy')
                                  .format(t.createdAt)),
                        ]),
                  ),
                ),

                // Subtasks card
                if (t.subtasks.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  Card(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                          crossAxisAlignment:
                              CrossAxisAlignment.start,
                          children: [
                            Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text('Subtasks',
                                      style: Theme.of(context)
                                          .textTheme
                                          .titleMedium),
                                  Text(
                                      '${(t.progress * 100).toInt()}%',
                                      style: TextStyle(
                                          color: Theme.of(context)
                                              .colorScheme
                                              .primary,
                                          fontWeight:
                                              FontWeight.bold,
                                          fontSize: 16)),
                                ]),
                            const SizedBox(height: 8),
                            ClipRRect(
                              borderRadius:
                                  BorderRadius.circular(6),
                              child: LinearProgressIndicator(
                                  value: t.progress,
                                  minHeight: 10),
                            ),
                            const SizedBox(height: 12),
                            ...t.subtasks.map((s) =>
                                CheckboxListTile(
                                  dense: true,
                                  value: s.isCompleted,
                                  onChanged: (_) =>
                                      provider.toggleSubtask(
                                          t.id, s.id),
                                  title: Text(s.title,
                                      style: TextStyle(
                                          decoration: s.isCompleted
                                              ? TextDecoration
                                                  .lineThrough
                                              : null,
                                          color: s.isCompleted
                                              ? Colors.grey
                                              : null)),
                                )),
                          ]),
                    ),
                  ),
                ],
              ]),
        ),
      );
    });
  }

  Widget _label(String text) => Text(text,
      style: const TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 12,
          color: Colors.grey));

  Widget _row(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child:
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, size: 18, color: Colors.grey),
        const SizedBox(width: 8),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label,
              style: const TextStyle(
                  fontSize: 11, color: Colors.grey)),
          Text(value, style: const TextStyle(fontSize: 14)),
        ]),
      ]),
    );
  }
}
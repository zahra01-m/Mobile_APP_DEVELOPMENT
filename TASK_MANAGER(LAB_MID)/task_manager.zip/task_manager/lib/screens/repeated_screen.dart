import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/task_provider.dart';
import '../widgets/task_card.dart';

class RepeatedScreen extends StatelessWidget {
  const RepeatedScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<TaskProvider>(builder: (_, p, __) {
      final tasks = p.repeatedTasks;
      if (tasks.isEmpty) {
        return const Center(
          child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('🔄', style: TextStyle(fontSize: 64)),
                SizedBox(height: 16),
                Text('No repeated tasks',
                    style:
                        TextStyle(fontSize: 18, color: Colors.grey)),
              ]),
        );
      }
      return ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: tasks.length,
        itemBuilder: (_, i) => TaskCard(task: tasks[i]),
      );
    });
  }
}
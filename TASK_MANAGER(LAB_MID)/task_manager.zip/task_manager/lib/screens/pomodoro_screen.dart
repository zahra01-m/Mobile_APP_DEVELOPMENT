import 'dart:async';
import 'package:flutter/material.dart';

class PomodoroScreen extends StatefulWidget {
  const PomodoroScreen({super.key});

  @override
  State<PomodoroScreen> createState() => _PomodoroScreenState();
}

class _PomodoroScreenState extends State<PomodoroScreen>
    with SingleTickerProviderStateMixin {
  static const _workSecs = 25 * 60;
  static const _shortBreak = 5 * 60;
  static const _longBreak = 15 * 60;

  int _seconds = _workSecs;
  bool _running = false;
  bool _isWork = true;
  int _cycles = 0;
  Timer? _timer;
  late AnimationController _pulse;

  @override
  void initState() {
    super.initState();
    _pulse = AnimationController(
        vsync: this, duration: const Duration(seconds: 1))
      ..repeat(reverse: true);
  }

  @override
  void dispose() {
    _timer?.cancel();
    _pulse.dispose();
    super.dispose();
  }

  int get _totalSecs {
    if (_isWork) return _workSecs;
    return (_cycles > 0 && _cycles % 4 == 0)
        ? _longBreak
        : _shortBreak;
  }

  void _toggle() {
    setState(() => _running = !_running);
    if (_running) {
      _timer =
          Timer.periodic(const Duration(seconds: 1), (_) {
        if (_seconds > 0) {
          setState(() => _seconds--);
        } else {
          _timer?.cancel();
          setState(() {
            if (_isWork) _cycles++;
            _isWork = !_isWork;
            _seconds = _totalSecs;
            _running = false;
          });
          _showSnack();
        }
      });
    } else {
      _timer?.cancel();
    }
  }

  void _reset() {
    _timer?.cancel();
    setState(() {
      _seconds = _totalSecs;
      _running = false;
    });
  }

  void _skip() {
    _timer?.cancel();
    setState(() {
      if (_isWork) _cycles++;
      _isWork = !_isWork;
      _seconds = _totalSecs;
      _running = false;
    });
  }

  void _showSnack() {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(_isWork ? '☕ Break time!' : '🔥 Focus time!'),
      duration: const Duration(seconds: 3),
    ));
  }

  String get _timeStr =>
      '${(_seconds ~/ 60).toString().padLeft(2, '0')}'
      ':${(_seconds % 60).toString().padLeft(2, '0')}';

  double get _progress => 1 - _seconds / _totalSecs;

  String get _modeLabel {
    if (_isWork) return '🔥 Focus Time';
    return (_cycles > 0 && _cycles % 4 == 0)
        ? '🌿 Long Break'
        : '☕ Short Break';
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final color =
        _isWork ? theme.colorScheme.primary : Colors.green;

    return Scaffold(
      appBar: AppBar(
        title: const Text('🍅 Pomodoro Timer'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(children: [
          // Mode chip
          AnimatedBuilder(
            animation: _pulse,
            builder: (_, __) => Opacity(
              opacity:
                  _running ? 0.6 + 0.4 * _pulse.value : 1.0,
              child: Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 24, vertical: 10),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                  border:
                      Border.all(color: color.withOpacity(0.3)),
                ),
                child: Text(_modeLabel,
                    style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                        color: color)),
              ),
            ),
          ),

          const SizedBox(height: 40),

          // Timer ring
          SizedBox(
            height: 240,
            width: 240,
            child: Stack(alignment: Alignment.center, children: [
              SizedBox(
                height: 240,
                width: 240,
                child: CircularProgressIndicator(
                  value: 1.0,
                  strokeWidth: 16,
                  valueColor: AlwaysStoppedAnimation<Color>(
                      Colors.grey.shade200),
                ),
              ),
              SizedBox(
                height: 240,
                width: 240,
                child: CircularProgressIndicator(
                  value: _progress,
                  strokeWidth: 16,
                  strokeCap: StrokeCap.round,
                  valueColor:
                      AlwaysStoppedAnimation<Color>(color),
                ),
              ),
              Column(mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                Text(_timeStr,
                    style: const TextStyle(
                        fontSize: 52,
                        fontWeight: FontWeight.bold)),
                Text('Cycle ${_cycles + 1}',
                    style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey[600])),
              ]),
            ]),
          ),

          const SizedBox(height: 40),

          // Controls
          Row(mainAxisAlignment: MainAxisAlignment.center,
              children: [
                OutlinedButton.icon(
                  onPressed: _reset,
                  icon: const Icon(Icons.refresh, size: 18),
                  label: const Text('Reset'),
                  style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 12)),
                ),
                const SizedBox(width: 10),
                FilledButton.icon(
                  onPressed: _toggle,
                  icon: Icon(
                      _running
                          ? Icons.pause_rounded
                          : Icons.play_arrow_rounded,
                      size: 24),
                  label: Text(_running ? 'Pause' : 'Start',
                      style: const TextStyle(fontSize: 15)),
                  style: FilledButton.styleFrom(
                    backgroundColor: color,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 12),
                  ),
                ),
                const SizedBox(width: 10),
                OutlinedButton.icon(
                  onPressed: _skip,
                  icon: const Icon(Icons.skip_next_rounded, size: 18),
                  label: const Text('Skip'),
                  style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 12)),
                ),
              ]),

          const SizedBox(height: 32),

          // Info card
          Card(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                  mainAxisAlignment:
                      MainAxisAlignment.spaceAround,
                  children: [
                    _info('🍅', 'Cycles', '$_cycles'),
                    _divider(),
                    _info(
                        '🎯',
                        'Next Break',
                        (_cycles + 1) % 4 == 0
                            ? 'Long (15m)'
                            : 'Short (5m)'),
                    _divider(),
                    _info('⏱️', 'Focus Time',
                        '${_cycles * 25} min'),
                  ]),
            ),
          ),

          const SizedBox(height: 16),

          // Tips card
          Card(
            color: color.withOpacity(0.08),
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('💡 How Pomodoro Works',
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: color)),
                    const SizedBox(height: 8),
                    const Text(
                      '1. Focus for 25 minutes\n'
                      '2. Take a 5 min short break\n'
                      '3. After 4 cycles → 15 min long break\n'
                      '4. Repeat to stay productive!',
                      style:
                          TextStyle(fontSize: 13, height: 1.7),
                    ),
                  ]),
            ),
          ),
        ]),
      ),
    );
  }

  Widget _info(String emoji, String label, String value) {
    return Column(children: [
      Text(emoji, style: const TextStyle(fontSize: 22)),
      const SizedBox(height: 4),
      Text(value,
          style: const TextStyle(
              fontWeight: FontWeight.bold, fontSize: 16)),
      Text(label,
          style:
              const TextStyle(fontSize: 11, color: Colors.grey)),
    ]);
  }

  Widget _divider() => Container(
      height: 50, width: 1, color: Colors.grey[300]);
}
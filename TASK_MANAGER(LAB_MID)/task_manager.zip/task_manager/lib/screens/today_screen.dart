import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../providers/task_provider.dart';
import '../widgets/task_card.dart';

class TodayScreen extends StatelessWidget {
  const TodayScreen({super.key});

  Widget _sectionHeader(
      BuildContext context, IconData icon, String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.88),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(children: [
        Icon(icon, color: Colors.white, size: 18),
        const SizedBox(width: 6),
        Text(label,
            style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 14)),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<TaskProvider>(builder: (_, p, __) {
      final overdue = p.overdueTasks;
      final today = p.todayTasks;
      final future = p.futureTasks;

      if (overdue.isEmpty && today.isEmpty && future.isEmpty) {
        return Center(
          child: Container(
            margin: const EdgeInsets.all(32),
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.85),
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('🎉', style: TextStyle(fontSize: 64)),
                SizedBox(height: 16),
                Text('All caught up!',
                    style: TextStyle(
                        fontSize: 22, fontWeight: FontWeight.bold)),
                SizedBox(height: 8),
                Text('No tasks at all',
                    style: TextStyle(fontSize: 15, color: Colors.grey)),
              ],
            ),
          ),
        );
      }

      return ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
        children: [

          // ── Overdue ──────────────────────────────
          if (overdue.isNotEmpty) ...[
            _sectionHeader(context, Icons.warning_amber_rounded,
                'Overdue (${overdue.length})', Colors.red),
            const SizedBox(height: 8),
            ...overdue.map((t) => TaskCard(task: t)),
            const SizedBox(height: 12),
          ],

          // ── Today's Tasks ─────────────────────────
          _sectionHeader(
            context,
            Icons.today,
            today.isEmpty
                ? "Today's Tasks (0)"
                : "Today's Tasks (${today.length})",
            Theme.of(context).colorScheme.primary,
          ),
          const SizedBox(height: 8),
          if (today.isEmpty)
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.7),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('✅ ', style: TextStyle(fontSize: 18)),
                  Text('No tasks for today',
                      style: TextStyle(color: Colors.grey, fontSize: 14)),
                ],
              ),
            )
          else
            ...today.map((t) => TaskCard(task: t)),
          const SizedBox(height: 12),

          // ── Upcoming (Future) ──────────────────────
          if (future.isNotEmpty) ...[
            _sectionHeader(context, Icons.upcoming_outlined,
                'Upcoming (${future.length})', Colors.teal),
            const SizedBox(height: 8),
            // Group by date
            ...() {
              final grouped = <String, List>{};
              for (final t in future) {
                final key = DateFormat('EEE, MMM dd yyyy').format(t.dueDate);
                grouped.putIfAbsent(key, () => []).add(t);
              }
              final widgets = <Widget>[];
              grouped.forEach((date, tasks) {
                widgets.add(
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6, top: 4),
                    child: Row(children: [
                      const Icon(Icons.calendar_today,
                          size: 13, color: Colors.white70),
                      const SizedBox(width: 6),
                      Text(date,
                          style: const TextStyle(
                              fontSize: 12,
                              color: Colors.white70,
                              fontWeight: FontWeight.w500)),
                    ]),
                  ),
                );
                for (final t in tasks) {
                  widgets.add(TaskCard(task: t));
                }
              });
              return widgets;
            }(),
          ],
        ],
      );
    });
  }
}
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/task_provider.dart';
import '../providers/theme_provider.dart';
import '../services/export_service.dart';
import '../widgets/app_background.dart';
import '../widgets/task_card.dart';
import 'today_screen.dart';
import 'completed_screen.dart';
import 'repeated_screen.dart';
import 'stats_screen.dart';
import 'add_task_screen.dart';
import 'pomodoro_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _index = 0;
  String _searchQuery = '';

  final _screens = const [
    TodayScreen(),
    CompletedScreen(),
    RepeatedScreen(),
    StatsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      // ✅ Scaffold transparent — background dikhega
      backgroundColor: Colors.transparent,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        // ✅ AppBar bhi transparent — bg image ke saath blend hoga
        backgroundColor: Colors.transparent,
        elevation: 0,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Colors.black.withOpacity(0.4),
                Colors.transparent,
              ],
            ),
          ),
        ),
        title: const Text(
          '📋 Task Manager',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            overflow: TextOverflow.ellipsis,
          ),
        ),
        centerTitle: false,
        actions: [
          // Pomodoro
          IconButton(
            tooltip: 'Pomodoro Timer',
            icon: const Text('🍅', style: TextStyle(fontSize: 20)),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const PomodoroScreen()),
            ),
          ),
          // Theme toggle
          Consumer<ThemeProvider>(
            builder: (_, tp, __) => IconButton(
              icon: Icon(
                tp.isDarkMode ? Icons.light_mode : Icons.dark_mode,
                color: Colors.white,
              ),
              tooltip: 'Toggle Theme',
              onPressed: tp.toggleTheme,
            ),
          ),
          // Export menu
          PopupMenuButton<String>(
            icon: const Icon(Icons.ios_share, color: Colors.white),
            tooltip: 'Export',
            onSelected: _handleExport,
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'csv', child: Text('📊 Export CSV')),
              PopupMenuItem(value: 'pdf', child: Text('📄 Export PDF')),
              PopupMenuItem(value: 'email', child: Text('📧 Export via Email')),
            ],
          ),
        ],
      ),
      // ✅ AppBackground wrap karo — poore body pe image dikhegi
      body: AppBackground(
        child: Column(
          children: [
            // AppBar ke liye space
            SizedBox(height: MediaQuery.of(context).padding.top + kToolbarHeight),

            // Search bar (hidden on Stats tab)
            if (_index != 3)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                child: TextField(
                  decoration: InputDecoration(
                    hintText: 'Search tasks...',
                    prefixIcon: const Icon(Icons.search, size: 20),
                    suffixIcon: _searchQuery.isNotEmpty
                        ? IconButton(
                      icon: const Icon(Icons.clear, size: 18),
                      onPressed: () =>
                          setState(() => _searchQuery = ''),
                    )
                        : null,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    filled: true,
                    fillColor: Colors.white.withOpacity(0.85),
                    isDense: true,
                    contentPadding:
                    const EdgeInsets.symmetric(vertical: 10),
                  ),
                  onChanged: (v) => setState(() => _searchQuery = v),
                ),
              ),

            // Overdue banner
            if (_index != 3)
              Consumer<TaskProvider>(
                builder: (_, p, __) {
                  if (p.overdueCount == 0) return const SizedBox();
                  return Container(
                    width: double.infinity,
                    margin: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: Colors.red.withOpacity(0.85),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.warning_amber_rounded,
                            color: Colors.white, size: 16),
                        const SizedBox(width: 8),
                        Flexible(
                          child: Text(
                            '${p.overdueCount} overdue task'
                                '${p.overdueCount > 1 ? "s" : ""}',
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),

            // Main content
            Expanded(
              child: _searchQuery.isNotEmpty
                  ? _buildSearchResults()
                  : _screens[_index],
            ),
          ],
        ),
      ),

      // Bottom nav — theme-aware, transparent background
      bottomNavigationBar: Builder(builder: (context) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        return Container(
          decoration: BoxDecoration(
            // ✅ Dark: subtle dark glass | Light: white glass
            color: isDark
                ? Colors.black.withOpacity(0.45)
                : Colors.white.withOpacity(0.75),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.15),
                blurRadius: 12,
              ),
            ],
          ),
          child: NavigationBarTheme(
            data: NavigationBarThemeData(
              backgroundColor: Colors.transparent,
              indicatorColor: isDark
                  ? Colors.white.withOpacity(0.2)
                  : const Color(0xFF6C63FF).withOpacity(0.15),
              // ✅ Selected: white in dark, purple in light
              iconTheme: WidgetStateProperty.resolveWith((states) {
                final selected = states.contains(WidgetState.selected);
                return IconThemeData(
                  color: selected
                      ? (isDark ? Colors.white : const Color(0xFF6C63FF))
                      : (isDark
                      ? Colors.white.withOpacity(0.45)
                      : Colors.black45),
                  size: selected ? 24 : 22,
                );
              }),
              labelTextStyle: WidgetStateProperty.resolveWith((states) {
                final selected = states.contains(WidgetState.selected);
                return TextStyle(
                  fontSize: selected ? 12 : 11,
                  fontWeight:
                  selected ? FontWeight.bold : FontWeight.normal,
                  color: selected
                      ? (isDark ? Colors.white : const Color(0xFF6C63FF))
                      : (isDark
                      ? Colors.white.withOpacity(0.45)
                      : Colors.black45),
                );
              }),
            ),
            child: NavigationBar(
              selectedIndex: _index,
              backgroundColor: Colors.transparent,
              onDestinationSelected: (i) => setState(() => _index = i),
              destinations: const [
                NavigationDestination(
                  icon: Icon(Icons.today_outlined),
                  selectedIcon: Icon(Icons.today),
                  label: 'Today',
                ),
                NavigationDestination(
                  icon: Icon(Icons.check_circle_outline),
                  selectedIcon: Icon(Icons.check_circle),
                  label: 'Completed',
                ),
                NavigationDestination(
                  icon: Icon(Icons.repeat),
                  selectedIcon: Icon(Icons.repeat_on),
                  label: 'Repeated',
                ),
                NavigationDestination(
                  icon: Icon(Icons.bar_chart_outlined),
                  selectedIcon: Icon(Icons.bar_chart),
                  label: 'Stats',
                ),
              ],
            ),
          ),
        );
      }),

      // FAB
      floatingActionButton: _index != 3
          ? FloatingActionButton.extended(
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute(
              builder: (_) => const AddTaskScreen()),
        ),
        backgroundColor: Colors.white.withOpacity(0.9),
        foregroundColor: const Color(0xFF6C63FF),
        icon: const Icon(Icons.add),
        label: const Text('Add Task',
            style: TextStyle(fontWeight: FontWeight.bold)),
      )
          : null,
    );
  }

  Widget _buildSearchResults() {
    return Consumer<TaskProvider>(
      builder: (_, p, __) {
        final results = p.searchTasks(_searchQuery);
        if (results.isEmpty) {
          return Center(
            child: Container(
              margin: const EdgeInsets.all(32),
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.85),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('🔍', style: TextStyle(fontSize: 48)),
                  const SizedBox(height: 16),
                  Text(
                    'No results for "$_searchQuery"',
                    style: const TextStyle(
                        fontSize: 16, color: Colors.grey),
                  ),
                ],
              ),
            ),
          );
        }
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text(
              '${results.length} result'
                  '${results.length > 1 ? "s" : ""}',
              style: const TextStyle(
                  color: Colors.white70, fontSize: 13),
            ),
            const SizedBox(height: 8),
            ...results.map((t) => TaskCard(task: t)),
          ],
        );
      },
    );
  }

  void _handleExport(String type) async {
    final tasks = context.read<TaskProvider>().tasks;
    final svc = ExportService();
    try {
      if (type == 'csv') await svc.exportToCSV(tasks);
      if (type == 'pdf') await svc.exportToPDF(tasks);
      if (type == 'email') await svc.exportViaEmail(tasks);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Export failed: $e')),
        );
      }
    }
  }
}
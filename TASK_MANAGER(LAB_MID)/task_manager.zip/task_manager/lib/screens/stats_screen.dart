import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/task_provider.dart';

class StatsScreen extends StatelessWidget {
  const StatsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<TaskProvider>(builder: (_, p, __) {
      final theme = Theme.of(context);

      return SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ── Completion Ring (Fixed Layout) ─────────────────
              Card(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16)),
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 30, horizontal: 16),
                  child: Row(
                      mainAxisAlignment:
                      MainAxisAlignment.spaceEvenly,
                      children: [
                        // Progress Circle Fix
                        SizedBox(
                          height: 110,
                          width: 110,
                          child: Stack(
                              alignment: Alignment.center,
                              children: [
                                SizedBox(
                                  height: 110,
                                  width: 110,
                                  child: CircularProgressIndicator(
                                    value: p.completionRate,
                                    strokeWidth: 10,
                                    backgroundColor:
                                    Colors.grey[200],
                                    valueColor:
                                    AlwaysStoppedAnimation<Color>(
                                        theme.colorScheme.primary),
                                  ),
                                ),
                                Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text(
                                        '${(p.completionRate * 100).toInt()}%',
                                        style: const TextStyle(
                                            fontSize: 22, // Size adjusted to fit
                                            fontWeight:
                                            FontWeight.bold),
                                      ),
                                      Text('done',
                                          style: TextStyle(
                                              fontSize: 12,
                                              color: Colors.grey[600],
                                              height: 1.0)),
                                    ]),
                              ]),
                        ),
                        // Legend
                        Column(
                            crossAxisAlignment:
                            CrossAxisAlignment.start,
                            children: [
                              _dot(theme.colorScheme.primary,
                                  'Completed: ${p.completedCount}'),
                              const SizedBox(height: 10),
                              _dot(Colors.grey.shade300,
                                  'Pending: ${p.pendingCount}'),
                              const SizedBox(height: 10),
                              _dot(Colors.red,
                                  'Overdue: ${p.overdueCount}'),
                              const SizedBox(height: 10),
                              _dot(Colors.orange,
                                  'High Priority: ${p.highPriorityCount}'),
                            ]),
                      ]),
                ),
              ),

              const SizedBox(height: 16),
              Text('Overview',
                  style: theme.textTheme.titleMedium
                      ?.copyWith(fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),

              // ── Stats Grid ─────────────────────
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: 1.2,
                children: [
                  _statCard('📋', 'Total', '${p.totalCount}',
                      Colors.blue),
                  _statCard('✅', 'Completed',
                      '${p.completedCount}', Colors.green),
                  _statCard('⏳', 'Pending', '${p.pendingCount}',
                      Colors.orange),
                  _statCard('🔥', 'High Priority',
                      '${p.highPriorityCount}', Colors.red),
                  _statCard('⚠️', 'Overdue', '${p.overdueCount}',
                      Colors.red.shade800),
                  _statCard('🔄', 'Repeated',
                      '${p.repeatedTasks.length}', Colors.purple),
                ],
              ),

              const SizedBox(height: 16),
              Text('By Category',
                  style: theme.textTheme.titleMedium
                      ?.copyWith(fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),

              // ── Category Bars ──────────────────
              ...['Work', 'Study', 'Personal', 'Health', 'Other']
                  .map((cat) {
                final total =
                    p.tasks.where((t) => t.category == cat).length;
                final done = p.tasks
                    .where(
                        (t) => t.category == cat && t.isCompleted)
                    .length;
                final rate = total == 0 ? 0.0 : done / total;
                final color = cat == 'Work'
                    ? Colors.blue
                    : cat == 'Study'
                    ? Colors.purple
                    : cat == 'Health'
                    ? Colors.green
                    : cat == 'Personal'
                    ? Colors.pink
                    : Colors.grey;

                return Card(
                  margin: const EdgeInsets.only(bottom: 8),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Column(children: [
                      Row(
                          mainAxisAlignment:
                          MainAxisAlignment.spaceBetween,
                          children: [
                            Row(children: [
                              CircleAvatar(
                                  radius: 6,
                                  backgroundColor: color),
                              const SizedBox(width: 8),
                              Text(cat,
                                  style: const TextStyle(
                                      fontWeight: FontWeight.w500)),
                            ]),
                            Text('$done / $total',
                                style: TextStyle(
                                    color: Colors.grey[600],
                                    fontSize: 13)),
                          ]),
                      const SizedBox(height: 8),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(4),
                        child: LinearProgressIndicator(
                          value: rate,
                          minHeight: 6,
                          backgroundColor: Colors.grey[200],
                          valueColor:
                          AlwaysStoppedAnimation<Color>(color),
                        ),
                      ),
                    ]),
                  ),
                );
              }),
            ]),
      );
    });
  }

  Widget _dot(Color color, String label) {
    return Row(children: [
      CircleAvatar(radius: 6, backgroundColor: color),
      const SizedBox(width: 10),
      Text(label, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w400)),
    ]);
  }

  Widget _statCard(
      String emoji, String label, String value, Color color) {
    return Card(
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(emoji, style: const TextStyle(fontSize: 26)),
              const SizedBox(height: 4),
              Text(value,
                  style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: color)),
              Text(label,
                  style: const TextStyle(
                      fontSize: 11, color: Colors.grey),
                  textAlign: TextAlign.center),
            ]),
      ),
    );
  }
}
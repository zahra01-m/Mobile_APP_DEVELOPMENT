import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';
import '../models/task.dart';
import '../providers/task_provider.dart';
import '../services/notification_service.dart';

class AddTaskScreen extends StatefulWidget {
  final Task? task;
  const AddTaskScreen({super.key, this.task});

  @override
  State<AddTaskScreen> createState() => _AddTaskScreenState();
}

class _AddTaskScreenState extends State<AddTaskScreen> {
  final _formKey = GlobalKey<FormState>();
  final _scrollController = ScrollController();
  // ✅ FocusNode — keyboard/focus control
  final _titleFocus = FocusNode();
  final _descFocus = FocusNode();

  late TextEditingController _titleCtrl;
  late TextEditingController _descCtrl;
  late DateTime _date;
  TimeOfDay? _time;
  bool _isRepeated = false;
  List<String> _repeatDays = [];
  String _sound = 'default';
  String _priority = 'medium';
  String _category = 'Personal';
  List<Subtask> _subtasks = [];
  final _subCtrl = TextEditingController();

  final _days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  final _categories = ['Work', 'Study', 'Personal', 'Health', 'Other'];

  final _soundOptions = const {
    'default': '🔔 Default',
    'bell': '🛎️ Bell',
    'chime': '🎵 Chime',
    'alarm': '⏰ Alarm',
  };

  @override
  void initState() {
    super.initState();
    final t = widget.task;
    _titleCtrl = TextEditingController(text: t?.title ?? '');
    _descCtrl = TextEditingController(text: t?.description ?? '');
    final rawDate = t?.dueDate ?? DateTime.now();
    _date = DateTime(rawDate.year, rawDate.month, rawDate.day);
    _time = t?.dueHour != null
        ? TimeOfDay(hour: t!.dueHour!, minute: t.dueMinute!)
        : null;
    _isRepeated = t?.isRepeated ?? false;
    _repeatDays = List.from(t?.repeatDays ?? []);
    _sound = t?.notificationSound ?? 'default';
    _priority = t?.priority ?? 'medium';
    _category = t?.category ?? 'Personal';
    _subtasks = List.from(t?.subtasks ?? []);
  }

  @override
  void dispose() {
    _titleCtrl.dispose();
    _descCtrl.dispose();
    _subCtrl.dispose();
    _scrollController.dispose();
    _titleFocus.dispose();
    _descFocus.dispose();
    super.dispose();
  }

  // ✅ Focus hatao pehle — phir action karo
  void _unfocus() {
    _titleFocus.unfocus();
    _descFocus.unfocus();
    FocusScope.of(context).unfocus();
  }

  void _setStateKeepScroll(VoidCallback fn) {
    final offset = _scrollController.hasClients ? _scrollController.offset : 0.0;
    setState(fn);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) _scrollController.jumpTo(offset);
    });
  }

  Color get _priorityColor {
    switch (_priority) {
      case 'high': return Colors.red;
      case 'low': return Colors.green;
      default: return Colors.orange;
    }
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.task != null;

    return Scaffold(
      appBar: AppBar(
        title: Text(isEdit ? '✏️ Edit Task' : '➕ New Task'),
        centerTitle: true,
      ),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          controller: _scrollController,
          padding: const EdgeInsets.all(16),
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ── Title ──────────────────────────
                TextFormField(
                  controller: _titleCtrl,
                  focusNode: _titleFocus,
                  decoration: const InputDecoration(
                    labelText: 'Task Title *',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.title),
                  ),
                  validator: (v) =>
                  v!.trim().isEmpty ? 'Title required' : null,
                ),
                const SizedBox(height: 16),

                // ── Description ────────────────────
                TextFormField(
                  controller: _descCtrl,
                  focusNode: _descFocus,
                  maxLines: 3,
                  // ✅ autofocus false — description pe focus nahi jayega
                  autofocus: false,
                  decoration: const InputDecoration(
                    labelText: 'Description (optional)',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.notes),
                  ),
                ),
                const SizedBox(height: 16),

                // ── Priority ───────────────────────
                Text('Priority',
                    style: Theme.of(context).textTheme.titleSmall),
                const SizedBox(height: 8),
                Row(
                  children: ['high', 'medium', 'low'].map((p) {
                    final color = p == 'high'
                        ? Colors.red
                        : p == 'medium' ? Colors.orange : Colors.green;
                    final isSelected = _priority == p;
                    return Expanded(
                      child: GestureDetector(
                        onTap: () {
                          _unfocus();
                          _setStateKeepScroll(() => _priority = p);
                        },
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          margin: const EdgeInsets.only(right: 8),
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          decoration: BoxDecoration(
                            color: isSelected
                                ? color.withOpacity(0.15)
                                : Colors.transparent,
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(
                              color: isSelected ? color : Colors.grey.shade300,
                              width: isSelected ? 2 : 1,
                            ),
                          ),
                          child: Column(children: [
                            Icon(
                              p == 'high'
                                  ? Icons.keyboard_double_arrow_up
                                  : p == 'medium'
                                  ? Icons.drag_handle
                                  : Icons.keyboard_double_arrow_down,
                              color: color, size: 20,
                            ),
                            const SizedBox(height: 4),
                            Text(
                              p[0].toUpperCase() + p.substring(1),
                              style: TextStyle(
                                color: color,
                                fontWeight: isSelected
                                    ? FontWeight.bold : FontWeight.normal,
                                fontSize: 13,
                              ),
                            ),
                          ]),
                        ),
                      ),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 16),

                // ── Category ───────────────────────
                Text('Category',
                    style: Theme.of(context).textTheme.titleSmall),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  children: _categories.map((cat) {
                    final color = cat == 'Work'
                        ? Colors.blue
                        : cat == 'Study'
                        ? Colors.purple
                        : cat == 'Health'
                        ? Colors.green
                        : cat == 'Personal'
                        ? Colors.pink
                        : Colors.grey;
                    return ChoiceChip(
                      label: Text(cat),
                      selected: _category == cat,
                      selectedColor: color.withOpacity(0.2),
                      labelStyle: TextStyle(
                        color: _category == cat ? color : null,
                        fontWeight: _category == cat
                            ? FontWeight.bold : FontWeight.normal,
                      ),
                      onSelected: (_) {
                        _unfocus();
                        _setStateKeepScroll(() => _category = cat);
                      },
                    );
                  }).toList(),
                ),
                const SizedBox(height: 16),

                // ── Due Date ───────────────────────
                _infoTile(Icons.calendar_today, 'Due Date',
                    DateFormat('EEE, MMM dd yyyy').format(_date), _pickDate),
                const SizedBox(height: 12),

                // ── Due Time ───────────────────────
                _infoTile(
                  Icons.access_time,
                  'Due Time (for notification)',
                  _time == null ? 'Tap to set time' : _time!.format(context),
                  _pickTime,
                  trailing: _time != null
                      ? IconButton(
                      icon: const Icon(Icons.clear),
                      onPressed: () {
                        _unfocus();
                        _setStateKeepScroll(() => _time = null);
                      })
                      : null,
                ),
                const SizedBox(height: 12),

                // ── Repeat ─────────────────────────
                Card(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                  child: Column(children: [
                    SwitchListTile(
                      title: const Text('Repeat Task'),
                      secondary: const Icon(Icons.repeat),
                      value: _isRepeated,
                      onChanged: (v) {
                        _unfocus();
                        _setStateKeepScroll(() {
                          _isRepeated = v;
                          if (!v) _repeatDays = [];
                        });
                      },
                    ),
                    if (_isRepeated) ...[
                      CheckboxListTile(
                        title: const Text('Every Day (Daily)'),
                        value: _repeatDays.contains('daily'),
                        onChanged: (v) => _setStateKeepScroll(() {
                          _repeatDays = v! ? ['daily'] : [];
                        }),
                      ),
                      if (!_repeatDays.contains('daily'))
                        Padding(
                          padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                          child: Wrap(
                            spacing: 8,
                            children: _days
                                .map((d) => FilterChip(
                              label: Text(d),
                              selected: _repeatDays.contains(d),
                              onSelected: (v) =>
                                  _setStateKeepScroll(() => v
                                      ? _repeatDays.add(d)
                                      : _repeatDays.remove(d)),
                            ))
                                .toList(),
                          ),
                        ),
                    ],
                  ]),
                ),
                const SizedBox(height: 12),

                // ── Notification Sound ─────────────
                _infoTile(
                  Icons.notifications_outlined,
                  'Notification Sound',
                  _soundOptions[_sound] ?? '🔔 Default',
                  _pickSound,
                ),
                const SizedBox(height: 12),

                // ── Subtasks ───────────────────────
                Card(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Subtasks',
                              style: Theme.of(context).textTheme.titleMedium),
                          const SizedBox(height: 8),
                          Row(children: [
                            Expanded(
                              child: TextField(
                                controller: _subCtrl,
                                decoration: const InputDecoration(
                                  hintText: 'Add a subtask...',
                                  border: OutlineInputBorder(),
                                  isDense: true,
                                ),
                                onSubmitted: (_) => _addSubtask(),
                              ),
                            ),
                            const SizedBox(width: 8),
                            IconButton.filled(
                                onPressed: _addSubtask,
                                icon: const Icon(Icons.add)),
                          ]),
                          ..._subtasks.asMap().entries.map((e) => ListTile(
                            dense: true,
                            leading: Checkbox(
                              value: e.value.isCompleted,
                              onChanged: (v) =>
                                  _setStateKeepScroll(() {
                                    _subtasks[e.key] = Subtask(
                                        id: e.value.id,
                                        title: e.value.title,
                                        isCompleted: v!);
                                  }),
                            ),
                            title: Text(e.value.title),
                            trailing: IconButton(
                              icon: const Icon(Icons.delete,
                                  size: 18, color: Colors.red),
                              onPressed: () => _setStateKeepScroll(
                                      () => _subtasks.removeAt(e.key)),
                            ),
                          )),
                        ]),
                  ),
                ),
                const SizedBox(height: 24),

                // ── Save Button ────────────────────
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: _save,
                    icon: const Icon(Icons.save),
                    label: Text(isEdit ? 'Update Task' : 'Add Task',
                        style: const TextStyle(fontSize: 16)),
                    style: FilledButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 16)),
                  ),
                ),
                const SizedBox(height: 16),
              ]),
        ),
      ),
    );
  }

  Widget _infoTile(IconData icon, String title, String subtitle,
      VoidCallback onTap, {Widget? trailing}) {
    return ListTile(
      leading: Icon(icon),
      title: Text(title),
      subtitle: Text(subtitle),
      trailing: trailing,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
          side: BorderSide(color: Colors.grey.shade300)),
      onTap: onTap,
    );
  }

  Future<void> _pickDate() async {
    _unfocus(); // ✅ focus hatao
    final picked = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),
    );
    if (picked != null) {
      _setStateKeepScroll(() =>
      _date = DateTime(picked.year, picked.month, picked.day));
    }
  }

  Future<void> _pickTime() async {
    _unfocus(); // ✅ focus hatao
    final picked = await showTimePicker(
        context: context, initialTime: _time ?? TimeOfDay.now());
    if (picked != null) _setStateKeepScroll(() => _time = picked);
  }

  void _pickSound() {
    _unfocus(); // ✅ focus hatao
    showDialog(
      context: context,
      builder: (ctx) => SimpleDialog(
        title: const Text('Notification Sound'),
        children: _soundOptions.entries.map((entry) {
          return RadioListTile<String>(
            title: Text(entry.value),
            value: entry.key,
            groupValue: _sound,
            onChanged: (v) {
              Navigator.pop(ctx);
              _setStateKeepScroll(() => _sound = v!);
            },
          );
        }).toList(),
      ),
    );
  }

  void _addSubtask() {
    final text = _subCtrl.text.trim();
    if (text.isEmpty) return;
    _setStateKeepScroll(() {
      _subtasks.add(Subtask(id: const Uuid().v4(), title: text));
      _subCtrl.clear();
    });
  }

  Future<void> _save() async {
    _unfocus();
    if (!_formKey.currentState!.validate()) return;
    final provider = context.read<TaskProvider>();
    final existing = widget.task;

    final taskId = existing?.id ?? const Uuid().v4();
    final notifId = existing?.notificationId ??
        (_time != null
            ? DateTime.now().millisecondsSinceEpoch % 99999
            : null);

    final task = Task(
      id: taskId,
      title: _titleCtrl.text.trim(),
      description: _descCtrl.text.trim(),
      dueDate: _date,
      dueHour: _time?.hour,
      dueMinute: _time?.minute,
      isCompleted: existing?.isCompleted ?? false,
      isRepeated: _isRepeated,
      repeatDays: _repeatDays,
      subtasks: _subtasks,
      notificationId: notifId,
      notificationSound: _sound,
      createdAt: existing?.createdAt ?? DateTime.now(),
      completedDates: existing?.completedDates ?? [],
      priority: _priority,
      category: _category,
    );

    if (existing != null) {
      await provider.updateTask(task);
      if (task.notificationId != null) {
        await NotificationService.cancelNotification(task.notificationId!);
      }
    } else {
      await provider.addTask(task);
    }

    if (_time != null && notifId != null) {
      await NotificationService.scheduleNotification(
        id: notifId,
        title: task.title,
        body: task.description.isNotEmpty
            ? task.description
            : 'Your task is due!',
        scheduledDate: DateTime(
          _date.year, _date.month, _date.day,
          _time!.hour, _time!.minute,
        ),
        taskId: taskId,
        soundName: _sound,
      );
    }

    if (mounted) Navigator.pop(context);
  }
}